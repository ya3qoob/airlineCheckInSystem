/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package investmentportfolio_g13;

/**
 * Subclass of Investment_G13
 * Mahmoud Soliman - 1080291 | Yaqoob Arshad - 1085654 | Imtiyaz Ali - 1085124
 * Course - CSC301, SEC-2
 */
public class Stock_G13 extends Investment_G13 {

    public Stock_G13(String name, String type, int quantity, double purchasePrice, double marketValue, String symbol,String riskLevel) {
        super(name, type, quantity, purchasePrice, marketValue,symbol,riskLevel);
    }
    
}
