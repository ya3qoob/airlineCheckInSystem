/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package investmentportfolio_g13;

/**
 * Investor class stores information regarding investors such as investorID,name,personalPortfolio
 * Mahmoud Soliman - 1080291 | Yaqoob Arshad - 1085654 | Imtiyaz Ali - 1085124
 * Course - CSC301, SEC-2
 */
public class Investor_G13 {

    private int investorID;
    private String name;
    private Portfolio_G13 personalPortfolio;
    private static int numOfInvestors = 0;

    // Constructor used when reading files
    public Investor_G13(int investorID, String name, Portfolio_G13 personalPortfolio) {
        this.investorID = investorID;
        this.name = name;
        this.personalPortfolio = personalPortfolio;
        numOfInvestors++;
    }

    // Constructor used when manually creating an investor
    public Investor_G13(String name, Portfolio_G13 personalPortfolio) {
        this.investorID = ++numOfInvestors;
        this.name = name;
        this.personalPortfolio = personalPortfolio;
    }
    
    public String getName() {
        return name;
    }

    public int getInvestorID() {
        return investorID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Portfolio_G13 getPersonalPortfolio() {
        return personalPortfolio;
    }

    public void setPersonalPortfolio(Portfolio_G13 personalPortfolio) {
        this.personalPortfolio = personalPortfolio;
    }

    // Returns information regarding investor
    public String toString() {
        return "ID:" + investorID + ", Name: " + name + ", " + personalPortfolio;
    }
    

}
