/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package investmentportfolio_g13;

/**
 * Subclass of Investment_G13, and implements Interest_G13 interface Made By:
 * Mahmoud Soliman - 1080291 | Yaqoob Arshad - 1085654 | Imtiyaz Ali - 1085124
 * Course - CSC301, SEC-2
 */
public class Bond_G13 extends Investment_G13 implements Interest_G13 {

    public Bond_G13(String name, String type, int quantity, double purchasePrice, double marketValue, String symbol, String riskLevel) {
        super(name, type, quantity, purchasePrice, marketValue, symbol, riskLevel);
    }

    public double calculateYearlyInterest(double value, double annualInterest, double year) {
        return value * Math.pow((1 + annualInterest / 100), year);
    }

    public double calculateMonthlyInterest(double value, double annualInterest, double year) {
        return value * Math.pow((1 + annualInterest / (100 * 12)), year * 12);
    }

    public double calculateQuarterlyInterest(double value, double annualInterest, double year) {
        return value * Math.pow((1 + annualInterest / (100 * 4)), year * 4);
    }
}
