/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package investmentportfolio_g13;

import java.util.ArrayList;

/**
 * Class stores list of investments, includes method to print list of investments
 * Mahmoud Soliman - 1080291 | Yaqoob Arshad - 1085654 | Imtiyaz Ali - 1085124
 * Course - CSC301, SEC-2
 */
public class Portfolio_G13 {

    private ArrayList<Investment_G13> investments;

    public Portfolio_G13() {
        investments = new ArrayList<>();
    }

    public Portfolio_G13(ArrayList<Investment_G13> investments) {
        this.investments = investments;
    }

    public ArrayList<Investment_G13> getInvestments() {
        return investments;
    }

    public void setInvestments(ArrayList<Investment_G13> investments) {
        this.investments = investments;
    }
    
    public void addInvestment(Investment_G13 investment){
        this.investments.add(investment);
    }
    
    // Loops through list of investments and prints their information
    public void printInvestments(){
        for(int i = 0; i < investments.size();i++){
            System.out.println(i+1+": "+investments.get(i));
        }
    }
    
    // returns size of investments as String 
    public String toString(){
        return ", No. Of Investments: "+investments.size();
    }
}
