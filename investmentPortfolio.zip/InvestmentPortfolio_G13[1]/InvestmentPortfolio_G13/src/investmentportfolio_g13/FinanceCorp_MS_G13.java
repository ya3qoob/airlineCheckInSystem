package investmentportfolio_g13;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
/*
Main class that runs different methods from current class, and other classes.
Includes methods that read from file, printing/adding/updating Investments, calculating total investment value.
and user interface.
Made By:
Mahmoud Soliman - 1080291
Yaqoob Arshad - 1085654
Imtiyaz Ali - 1085124
Course - CSC301, SEC-2
 */
public class FinanceCorp_MS_G13 {

    public static void main(String[] args) throws FileNotFoundException {
        Scanner input = new Scanner(System.in);
        ArrayList<Investor_G13> investors = new ArrayList<>(); // List of investors that hold all needed information
        int userChoice;
        do {
            DislayMenu();
            userChoice = UserMenuChoice();
            switch (userChoice) {
                case 1:
                    AddInvestmentToPortfolio(investors);
                    break; // 1-Add a new investment to a portfolio.
                case 2:
                    UpdateInvestmentDetails(investors);
                    break;// 2-Update investment details (quantity, purchase price, ...).
                case 3:
                    System.out.println("---------------------------------------------------------\n" + "Enter Path: ");
                    String directory = input.nextLine();
                    AddInvestmentsFromFile(investors, directory);
                    break;// 3-Bulk addition of investments from a file.
                case 4:
                    ListAllInvestments(investors);
                    break;// 4-List all investments in the portfolio of a selected customer.
                case 5:
                    CalculatePortfolioValue(investors);
                    break;// 5-Calculate the total portfolio value for a selected customer.

                default:
                    System.out.println("Thank you for using CSC301's Investment Portfolio Management System, Have a Good Bye.");
            }
        } while (userChoice != 0);
    }

    // Displays menu of available options
    public static void DislayMenu() {
        System.out.println("---------------------------------------------------------");
        System.out.println("Investment Portfolio Management System (FinanceCorp, Spring2024)");
        System.out.println("---------------------------------------------------------");
        System.out.println("1- Add a new investment to a portfolio.");
        System.out.println("2- Update investment details (quantity, purchase price, ...).");
        System.out.println("3- Bulk addition of investments from a file.");
        System.out.println("4- List all investments in the portfolio of a selected customer.");
        System.out.println("5- Calculate the total portfolio value for a selected customer.");
        System.out.println("0- Quit");
        System.out.println("---------------------------------------------------------");
    }

    /*
    Menu that prompts user to enter one of the available choices
     */
    public static int UserMenuChoice() {
        Scanner input = new Scanner(System.in);
        int choice = -1;
        do {
            try {
                System.out.println("Your choice (0, 1, 2, 3, 4, 5):");
                choice = input.nextInt();
            } catch (InputMismatchException ex) {
                System.out.println("Please enter a valid number.");
                input.nextLine();
            }
        } while (choice > 5 || choice < 0);
        return choice;
    }

    /* 
    Allows to add an investment to portfolio by selecting the investor by calling selectInvestor method, 
    then by entering the investment details it would create one of three possible objects, 
    Bond, Stock and MutualFund.
     */
    public static void AddInvestmentToPortfolio(ArrayList<Investor_G13> investors) {

        Scanner input = new Scanner(System.in);

        try {
            int choice;
            Investment_G13 newInvestment; // investment to be assigned and added to portfolio

            // calls selectInvestor method and returns an investor
            Investor_G13 selectedInvestor = selectInvestor(investors);

            // if selectedInvestor is null then returns
            if (selectedInvestor == null) {
                return;
            }

            // Now, ask the user for the investment details.
            System.out.print("Enter investment name: ");
            String name = input.nextLine();

            // Prompts user to choose investment type, loops if choice not in range (0,3)
            do {
                System.out.println("Enter investment type: \n1: Stock\n2: Bond\n3: MutualFund");
                choice = input.nextInt();
            } while (choice < 0 || choice > 3);

            // assign type based on choice, if chosen 1 then Stock, if chosen 2 then Bond, else MutualFund
            String type = (choice == 1) ? "Stock" : (choice == 2) ? "Bond" : "MutualFund";

            System.out.print("Enter quantity: ");
            int quantity = input.nextInt();

            System.out.print("Enter purchase price: ");
            double purchasePrice = input.nextDouble();

            System.out.print("Enter market value: ");
            double marketValue = input.nextDouble();
            input.nextLine(); // clear input

            System.out.print("Enter symbol: ");
            String symbol = input.nextLine();

            //Prompts user to choose risk level, loops if choice not in range (0,3)
            do {
                System.out.println("Enter Risk Level: \n1: Low\n2: Medium\n3: High");
                choice = input.nextInt();
            } while (choice < 0 || choice > 3);

            // assign riskLevel based on choice, if chosen 1 then Low, if chosen 2 then Medium, else High
            String riskLevel = (choice == 1) ? "low" : (choice == 2) ? "Medium" : "High";

            /*
            Create a new Investment object based on type.
            Case "Bond" allows to create Bond Object, 
            Case "Stock" allows to create Stock Object,
            Case "MutualFund" allows to create a MutualFund Object,
            Default: terminates the method by returing.
             */
            switch (type) {

                case "Bond":
                    newInvestment = new Bond_G13(name, type, quantity, purchasePrice, marketValue, symbol, riskLevel);
                    break;
                case "Stock":
                    newInvestment = new Stock_G13(name, type, quantity, purchasePrice, marketValue, symbol, riskLevel);
                    break;
                case "MutualFund":
                    newInvestment = new Stock_G13(name, type, quantity, purchasePrice, marketValue, symbol, riskLevel);
                    break;
                default:
                    System.out.println("Error: Not a valid option");
                    return;
            }
            // Add the new investment to the selected investor's portfolio.
            selectedInvestor.getPersonalPortfolio().addInvestment(newInvestment);

            System.out.println("New investment added to the portfolio of " + selectedInvestor.getName());

        } catch (InputMismatchException ex) {
            // Catches the error and clears input
            System.out.println("Error: Input Mismatch, exiting. . .");
            input.nextLine();
        }

    }

    /*
    Calls selectInvestor to select one of the available investors
    then a list of their available investments, if no investments 
    are available then exits method, else the user is prompted to enter new details for the selected investment
    that is to be updated.
     */
    public static void UpdateInvestmentDetails(ArrayList<Investor_G13> investors) {

        Scanner input = new Scanner(System.in);

        // calls selectInvestor method and returns an investor
        Investor_G13 selectedInvestor = selectInvestor(investors);

        // if selectedInvestor is null then returns
        if (selectedInvestor == null) {
            return;
        }

        // assigns investments of selected investor
        ArrayList<Investment_G13> selectedInvestments = selectedInvestor.getPersonalPortfolio().getInvestments();

        // If selected user has empty portfolio, print statement then exit method
        if (selectedInvestments.isEmpty()) {
            System.out.println("No available investments");
            return;
        }

        // reset counter to 0, and prints list of investment through a for-loop
        int x = 0, listSize = selectedInvestments.size();
        System.out.println("List of Investments: \n"
                + "---------------------------------------------------------\n" + "0: Exit");
        for (Investment_G13 investment : selectedInvestments) {
            System.out.println(++x + ": " + investment);
            
        }

        // Prompts user to choose one of the available investments, loops if choice is not in range (0, listSize)
        int investmentID = -1;
        do {
            try {
                investmentID = input.nextInt();
                System.out.print((investmentID < 0 || investmentID > listSize)
                        ? "Please select one of the correct values.\n" : "");
            } catch (InputMismatchException ex) {
                System.out.println("Error: Please enter a number.");
                input.nextLine();
            }
        } while (investmentID < 0 || investmentID > listSize);

        // if user chose 0 then exit method
        if (investmentID == 0) {
            return;
        }

        // Initialize the investment to be updated by using the user's choice
        Investment_G13 investmentToUpdate = selectedInvestments.get(investmentID - 1);

        // Now, ask the user for the updated investment details.
        input.nextLine(); // clears input
        try {

            System.out.println("Enter new Name: ");
            String newName = input.nextLine();
            System.out.println("Enter new Symbol: ");
            String newSymbol = input.next();
            int choice;

            // Prompts user to choose risk level, loops if choice not in range (0,3)
            do {
                System.out.println("Enter new Risk Level: \n1: Low\n2: Medium\n3: High");
                choice = input.nextInt();
            } while (choice < 0 || choice > 3);

            // assign newRiskLevel based on choice, if chosen 1 then Low, if chosen 2 then Medium, else High
            String newRiskLevel = (choice == 1) ? "low" : (choice == 2) ? "Medium" : "High";
            System.out.print("Enter new quantity: ");
            int newQuantity = input.nextInt();

            System.out.print("Enter new purchase price: ");
            double newPurchasePrice = input.nextDouble();

            System.out.print("Enter new market value: ");
            double newMarketValue = input.nextDouble();

            // updates investment information
            investmentToUpdate.setName(newName);
            investmentToUpdate.setSymbol(newSymbol);
            investmentToUpdate.setRiskLevel(newRiskLevel);
            investmentToUpdate.setQuantity(newQuantity);
            investmentToUpdate.setPurchasePrice(newPurchasePrice);
            investmentToUpdate.setMarketValue(newMarketValue);

            System.out.println("Investment details updated for " + investmentToUpdate.getName() + " in the portfolio of " + selectedInvestor.getName());
        } catch (InputMismatchException ex) {
            System.out.println("Error: Input mismatch, exiting. . .");
            input.nextLine();
        }

    }

    /*
    Reads a file from a directory entered by the user, exits the method if file does not exist. 
    If file does exist then splits each line into tokens, 
    and creates an investment object based on type stored in the file, 
    then adds the investment object to it's corresponding user by matching the IDs in tokens with the available
    investors in the investors list, 
    if investor does not exist, then creates an investor object and adds the investment to their portfolio.
     */
    public static void AddInvestmentsFromFile(ArrayList<Investor_G13> investors, String fileDirectory) {

        File investorsFile = new File(fileDirectory); // Reads File from fileDirectory parameter

        // Exit's if the investorsFile does not exist in entered directory
        if (!investorsFile.exists()) {
            System.out.println("File does not Exist.");
            return;
        }

        // Try to read file
        try ( Scanner input = new Scanner(investorsFile)) {

            /* 
            if first line with information related to column details is available then move to next line,
            if the second line has no available data, then prints that no data is available, 
            else print empty file if file is completely empty
             */
            if (input.hasNext()) {
                input.nextLine();
                System.out.print((!input.hasNext()) ? "No available Data\n" : "");
            } else {
                System.out.println("Empty file.");
                return;
            }

            boolean foundInvestor; // condition to see if an investor have been found, intitialized in loop.

            // Loops as long as a value exists in current line
            while (input.hasNext()) {
                String[] tokens = input.nextLine().split(",");
                Investment_G13 investment; // investment to be initialized in switch statement

                /*
                If the investment type is equal to one of the three options; MutualFund, Bond, Stock
                then the related Object will be intialized to a investment variable, default throws error that the 
                entered type does not exist.
                 */
                switch (tokens[3]) {

                    case "MutualFund":
                        // creates MutualFund Object with tokens
                        investment
                                = new MutualFund_G13(
                                        tokens[2], tokens[3], Integer.valueOf(tokens[4]), Double.valueOf(tokens[5]), Double.valueOf(tokens[6]), tokens[7], tokens[8]);
                        break;
                    case "Bond":
                        // Creates Bond Object with tokens
                        investment
                                = new Bond_G13(
                                        tokens[2], tokens[3], Integer.valueOf(tokens[4]), Double.valueOf(tokens[5]), Double.valueOf(tokens[6]), tokens[7], tokens[8]);
                        break;
                    case "Stock":
                        // Creates Stock Object with tokens
                        investment
                                = new Stock_G13(
                                        tokens[2], tokens[3], Integer.valueOf(tokens[4]), Double.valueOf(tokens[5]), Double.valueOf(tokens[6]), tokens[7], tokens[8]);
                        break;
                    default:
                        throw new IllegalArgumentException("Type does not exist.");
                }

                /* 
                Loops through the list to see if the investor already exists, if true, adds investment to investor's
                list of investments
                 */
                foundInvestor = false; // intitial condition to finding investor, assume false.
                for (int i = 0; i < investors.size(); i++) {
                    if (investors.get(i).getInvestorID() == Integer.valueOf(tokens[0])) {
                        investors.get(i).getPersonalPortfolio().addInvestment(investment);
                        foundInvestor = true;
                        break;
                    }
                }

                // Adds investor if the investor does not exist in the ArrayList; investors
                if (!foundInvestor) {
                    investors.add(new Investor_G13(Integer.valueOf(tokens[0]), tokens[1], new Portfolio_G13(new ArrayList<>())));
                    investors.get(investors.size() - 1).getPersonalPortfolio().addInvestment(investment);
                }
            }

        } catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    /*
    Calls selectInvestor to select one of the available investors, then prints all investments
     */
    public static void ListAllInvestments(ArrayList<Investor_G13> investors) {

        // calls selectInvestor method and returns an investor
        Investor_G13 selectedInvestor = selectInvestor(investors);

        // if selectedInvestor is null then returns
        if (selectedInvestor == null) {
            return;
        }
        // Prints name of investor, then calls method to print a list of investments
        System.out.println("---------------------------------------------------------\n" + "Investments of: " + selectedInvestor.getName());
        selectedInvestor.getPersonalPortfolio().printInvestments();
    }

    /*
    Calls selectInvestor method to select one of the available investors, 
    then calculates portfolio value of selected investor by adding sum through a loop
     */
    public static void CalculatePortfolioValue(ArrayList<Investor_G13> investors) {

        // calls selectInvestor method and returns an investor
        Investor_G13 selectedInvestor = selectInvestor(investors);

        // if selectedInvestor is null then returns
        if (selectedInvestor == null) {
            return;
        }
        // Prints name of investor, then calls method to print a list of investments
        System.out.println("---------------------------------------------------------\n"
                + "Portfolio value of: " + selectedInvestor.getName());

        // loop adds market value of each investment of selected investor
        int sum = 0;
        for (Investment_G13 investment : selectedInvestor.getPersonalPortfolio().getInvestments()) {
            sum += investment.getMarketValue();
        }
        System.out.println("Total: " + sum);
    }

    /* 
    Prints list of investors and prompts user to choose one of the available investors, 
    if empty prints statement that it is empty and returns null.
     */
    public static Investor_G13 selectInvestor(ArrayList<Investor_G13> investors) {

        // if investor list is empty, print statement then return null
        if (investors.isEmpty()) {
            System.out.println("List is empty");
            return null;
        }

        Scanner input = new Scanner(System.in);
        int listSize = investors.size(); // number of available investors

        // Loops through list of investors and prints their information
        System.out.println("List of Investors: \n"
                + "---------------------------------------------------------\n" + "0: Exit");
        for (int i = 0; i < investors.size(); i++) {
            System.out.println(i + 1 + ": " + investors.get(i));
        }

        // asks user to choose one of the investors, and loops if choice not in range (0,listSize)
        System.out.println("Choose an Investor");
        int choice = -1;
        do {
            try {
                choice = input.nextInt();
                System.out.print((choice < 0 || choice > listSize) ? "Please select one of the correct values.\n" : "");
            } catch (InputMismatchException ex) {
                System.out.println("Error: Please enter a number.");
                input.nextLine();
            }
        } while (choice < 0 || choice > listSize);

        // returns user choice if within range else returns null
        return (choice > 0 && choice <= listSize) ? investors.get(choice - 1) : null;
    }
}
