/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package investmentportfolio_g13;

/**
 *
 * @author user
 */
public interface Interest_G13 {

    double calculateYearlyInterest(double value, double interest, double period);
    
    double calculateMonthlyInterest(double value, double interest, double period);
    
    double calculateQuarterlyInterest(double value, double interest, double period);
    
    
}
