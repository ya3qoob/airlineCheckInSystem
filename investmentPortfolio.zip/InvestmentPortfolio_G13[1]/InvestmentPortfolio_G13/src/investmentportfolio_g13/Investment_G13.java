/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package investmentportfolio_g13;

/**
 * Abstract Superclass that holds basic investment information
 * Mahmoud Soliman - 1080291 | Yaqoob Arshad - 1085654 | Imtiyaz Ali - 1085124
 * Course - CSC301, SEC-2
 */
public abstract class Investment_G13 {

    private String name;
    private String type;
    private int quantity;
    private String symbol;
    private double purchasePrice;
    private double marketValue;
    private String riskLevel;

    public Investment_G13(String name, String type, int quantity, double purchasePrice, double marketValue, String symbol, String riskLevel) {
        this.name = name;
        this.type = type;
        this.quantity = quantity;
        this.purchasePrice = purchasePrice;
        this.marketValue = marketValue;
        this.symbol = symbol;
        this.riskLevel = riskLevel;
    }

    // Returns information about a generic investment as String
    public String toString() {
        return "Name: " + name + ", Symbol: " + symbol + ", Type: " + type + ", Quantity: " + quantity
                + ", Purchase Price: " + purchasePrice + ", Market Value: " + marketValue + ", Risk Level: " + riskLevel;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public double getPurchasePrice() {
        return purchasePrice;
    }

    public void setPurchasePrice(double purchasePrice) {
        this.purchasePrice = purchasePrice;
    }

    public double getMarketValue() {
        return marketValue;
    }

    public void setMarketValue(double marketValue) {
        this.marketValue = marketValue;
    }

    public String getRiskLevel() {
        return riskLevel;
    }

    public void setRiskLevel(String riskLevel) {
        this.riskLevel = riskLevel;
    }

}
